/**
 * Sidebar Manager
 * Handles sidebar functionality and AI interactions
 */
class SidebarManager {
    constructor() {
        this.selectedText = '';
        this.analysisResult = null;
        this.chatHistory = [];
        this.isAnalyzing = false;
        this.isProcessing = false;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupMessageHandler();
        this.setupResizeHandler();
        this.initializeChat();
        
        console.log('Sidebar manager initialized');
    }

    setupEventListeners() {
        // Close button
        const closeBtn = document.getElementById('closeSidebar');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeSidebar());
        }

        // Reanalyze button
        const reanalyzeBtn = document.getElementById('reanalyzeBtn');
        if (reanalyzeBtn) {
            reanalyzeBtn.addEventListener('click', () => this.analyzeText());
        }

        // Send message button
        const sendBtn = document.getElementById('sendButton');
        const chatInput = document.getElementById('chatInput');
        
        if (sendBtn && chatInput) {
            sendBtn.addEventListener('click', () => this.sendMessage());
            
            chatInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });

            // Auto-resize textarea
            chatInput.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = Math.min(this.scrollHeight, 100) + 'px';
            });
        }

        // Clear chat button
        const clearChatBtn = document.getElementById('clearChatBtn');
        if (clearChatBtn) {
            clearChatBtn.addEventListener('click', () => this.clearChat());
        }

        // Quick action buttons
        document.querySelectorAll('.quick-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const target = e.currentTarget;
                const prompt = target && target.getAttribute('data-prompt');
                if (prompt) {
                    this.useQuickPrompt(prompt);
                }
            });
        });

        // Escape key to close sidebar
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeSidebar();
            }
        });

        // Sidebar already dispatches close events; content script handles them
    }

    setupMessageHandler() {
        // Listen for messages from content script (same document events, legacy)
        document.addEventListener('misinfoMessage', (event) => {
            this.handleExternalMessage(event.detail);
        });

        // Listen to postMessage from content script (iframe embedding)
        window.addEventListener('message', (event) => {
            const data = event.data || {};
            if (data && data.type === 'misinfo:setSelectedText') {
                this.handleExternalMessage({ action: 'setSelectedText', text: data.text });
            } else if (data && data.type === 'misinfo:backgroundResponse') {
                const { requestId, response } = data;
                if (requestId && this._pendingRequests && this._pendingRequests.has(requestId)) {
                    const resolver = this._pendingRequests.get(requestId);
                    this._pendingRequests.delete(requestId);
                    resolver(response);
                }
            }
        });

        // Listen for async responses from background via content bridge (legacy document events)
        document.addEventListener('misinfoBackgroundResponse', (event) => {
            const { requestId, response } = event.detail || {};
            if (requestId && this._pendingRequests && this._pendingRequests.has(requestId)) {
                const resolver = this._pendingRequests.get(requestId);
                this._pendingRequests.delete(requestId);
                resolver(response);
            }
        });

        // Signal readiness to the parent content script
        try {
            window.parent && window.parent.postMessage({ type: 'misinfo:sidebarReady' }, '*');
        } catch (_) {}
    }

    setupResizeHandler() {
        let resizeTimeout;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                this.adjustLayout();
            }, 250);
        });
    }

    handleExternalMessage(message) {
        switch (message.action) {
            case 'setSelectedText':
                if (message.text && message.text !== this.selectedText) {
                    this.selectedText = message.text;
                    this.analyzeText();
                }
                break;
        }
    }

    initializeChat() {
        this.addChatMessage('bot', 
            "I'm ready to help you analyze this content! I can explain the credibility assessment, " +
            "suggest fact-checking approaches, and discuss any concerns you have about the information."
        );
    }

    async analyzeText() {
        if (this.isAnalyzing || !this.selectedText) return;
        
        this.isAnalyzing = true;
        this.showAnalyzingState();

        try {
            const response = await this.sendToBackground({
                action: 'analyzeText',
                text: this.selectedText
            });

            if (response && response.success) {
                this.analysisResult = response.analysis;
                this.displayAnalysisResult();
                this.addChatMessage('bot', 
                    "I've completed the analysis. You can ask me about specific aspects of the content " +
                    "or request guidance on verification steps."
                );
            } else {
                throw new Error(response?.error || 'Analysis failed');
            }
        } catch (error) {
            console.error('Analysis error:', error);
            this.showError('Analysis failed. Please try again.');
            this.addChatMessage('bot', 
                "I encountered an error during analysis. You can still ask me questions about the content."
            );
        } finally {
            this.isAnalyzing = false;
        }
    }

    showAnalyzingState() {
        const analysisResult = document.getElementById('analysisResult');
        if (analysisResult) {
            analysisResult.innerHTML = `
                <div class="loading-state">
                    <div class="spinner"></div>
                    <p>Analyzing content for misinformation indicators...</p>
                    <p style="font-size: 12px; color: #666; margin-top: 8px;">
                        Checking language patterns and credibility signals
                    </p>
                </div>
            `;
        }
    }

    displayAnalysisResult() {
        if (!this.analysisResult) return;

        const analysisResult = document.getElementById('analysisResult');
        if (!analysisResult) return;

        const riskColor = this.analysisResult.credibility?.color || '#666';
        const riskScore = this.analysisResult.riskScore || 0;
        const credibilityLevel = this.analysisResult.credibility?.level || 'UNKNOWN';
        const keywords = this.analysisResult.keywords?.found || [];
        const suggestions = this.analysisResult.suggestions || [];

        analysisResult.innerHTML = `
            <div class="analysis-result">
                <div class="risk-meter" style="border-left-color: ${riskColor}">
                    <div class="risk-score">
                        <span class="score-value" style="color: ${riskColor}">${riskScore}/100</span>
                        <span class="score-label">Risk Score</span>
                    </div>
                    <div class="credibility">
                        <span class="credibility-label">Credibility Level</span>
                        <span class="credibility-value" style="color: ${riskColor}">${credibilityLevel}</span>
                    </div>
                </div>
                
                <div class="explanation">
                    <h3>📊 Analysis Summary</h3>
                    <p>${this.analysisResult.explanation || 'No explanation available.'}</p>
                </div>
                
                ${keywords.length > 0 ? `
                    <div class="keywords">
                        <h3>🔍 Detected Indicators</h3>
                        <div class="keyword-list">
                            ${keywords.map(kw => 
                                `<span class="keyword-tag">${kw}</span>`
                            ).join('')}
                        </div>
                        <p style="font-size: 12px; color: #666; margin-top: 8px;">
                            ${keywords.length} potential indicator${keywords.length !== 1 ? 's' : ''} found
                        </p>
                    </div>
                ` : ''}
                
                ${suggestions.length > 0 ? `
                    <div class="suggestions">
                        <h3>💡 Recommended Actions</h3>
                        <ul>
                            ${suggestions.map(suggestion => 
                                `<li>${suggestion}</li>`
                            ).join('')}
                        </ul>
                    </div>
                ` : ''}
            </div>
        `;
    }

    async sendMessage() {
        if (this.isProcessing) return;
        
        const chatInput = document.getElementById('chatInput');
        if (!chatInput) return;

        const message = chatInput.value.trim();
        if (!message) return;

        this.isProcessing = true;
        
        // Add user message
        this.addChatMessage('user', message);
        chatInput.value = '';
        chatInput.style.height = 'auto';

        // Show typing indicator
        this.showTypingIndicator();

        try {
            const response = await this.getAIResponse(message);
            this.hideTypingIndicator();
            this.addChatMessage('bot', response);
            
            // Save to chat history
            this.chatHistory.push({
                user: message,
                bot: response,
                timestamp: new Date().toISOString()
            });
            
        } catch (error) {
            console.error('Error sending message:', error);
            this.hideTypingIndicator();
            this.addChatMessage('bot', 'Sorry, I encountered an error. Please try again.');
        } finally {
            this.isProcessing = false;
        }
    }

    useQuickPrompt(prompt) {
        const chatInput = document.getElementById('chatInput');
        if (chatInput) {
            chatInput.value = prompt;
            chatInput.focus();
            chatInput.style.height = 'auto';
            chatInput.style.height = Math.min(chatInput.scrollHeight, 100) + 'px';
        }
    }

    async getAIResponse(userMessage) {
        return new Promise((resolve) => {
            setTimeout(() => {
                let context = "Based on general misinformation detection principles, ";
                
                if (this.analysisResult) {
                    const riskScore = this.analysisResult.riskScore || 0;
                    const credibilityLevel = this.analysisResult.credibility?.level || 'UNKNOWN';
                    context = `Based on my analysis showing a ${riskScore}/100 risk score and ${credibilityLevel.toLowerCase()} credibility, `;
                }

                let response = context + "this content should be evaluated critically. Consider checking with reliable sources and looking for corroborating evidence.";
                
                if (userMessage.toLowerCase().includes('credibil')) {
                    response = context + "the credibility assessment considers factors like language objectivity, source reliability indicators, and consistency with established facts.";
                } else if (userMessage.toLowerCase().includes('source')) {
                    response = context + "I recommend verifying through primary sources, checking author credentials, and consulting multiple reliable outlets.";
                } else if (userMessage.toLowerCase().includes('fact') || userMessage.toLowerCase().includes('check')) {
                    response = context + "effective fact-checking involves checking dates, looking for original sources, and using established fact-checking organizations.";
                } else if (userMessage.toLowerCase().includes('risk') || userMessage.toLowerCase().includes('score')) {
                    const riskInterpretation = this.getRiskInterpretation();
                    response = context + `the risk score indicates ${riskInterpretation}.`;
                }

                resolve(response);
            }, 1000 + Math.random() * 1000);
        });
    }

    getRiskInterpretation() {
        if (!this.analysisResult) return 'moderate concern';
        
        const score = this.analysisResult.riskScore || 0;
        if (score < 20) return 'low concern';
        if (score < 50) return 'moderate concern';
        return 'high concern requiring careful verification';
    }

    addChatMessage(sender, content) {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;

        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${sender}`;
        
        const timeString = new Date().toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        messageDiv.innerHTML = `
            <div class="message-bubble">${content}</div>
            <div class="message-time">${timeString}</div>
        `;
        
        chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
    }

    showTypingIndicator() {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;

        let typingIndicator = chatMessages.querySelector('.typing-indicator');
        
        if (!typingIndicator) {
            typingIndicator = document.createElement('div');
            typingIndicator.className = 'chat-message bot typing-indicator';
            typingIndicator.innerHTML = `
                <div class="message-bubble">
                    <div class="typing-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <span class="typing-text">AI is analyzing...</span>
                </div>
            `;
            chatMessages.appendChild(typingIndicator);
        }
        
        this.scrollToBottom();
    }

    hideTypingIndicator() {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;

        const typingIndicator = chatMessages.querySelector('.typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    scrollToBottom() {
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }

    clearChat() {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;

        chatMessages.innerHTML = `
            <div class="welcome-message">
                <div class="message-bubble">
                    <strong>Chat cleared!</strong> You can start a new conversation about the content analysis.
                </div>
            </div>
        `;
        this.chatHistory = [];
    }

    adjustLayout() {
        this.scrollToBottom();
    }

    closeSidebar() {
        // Dispatch event to notify content script
        const event = new CustomEvent('misinfoCloseSidebar');
        document.dispatchEvent(event);
    }

    showError(message) {
        const analysisResult = document.getElementById('analysisResult');
        if (analysisResult) {
            analysisResult.innerHTML = `
                <div class="error-state">
                    <p>${message}</p>
                </div>
            `;
        }
    }

    sendToBackground(message) {
        // Use postMessage to the parent (content script) if in iframe
        if (!this._pendingRequests) this._pendingRequests = new Map();
        const requestId = 'req_' + Date.now() + '_' + Math.random().toString(36).slice(2);
        return new Promise((resolve) => {
            this._pendingRequests.set(requestId, resolve);
            try {
                if (window.parent && window.parent !== window) {
                    window.parent.postMessage({ type: 'misinfo:backgroundRequest', requestId, payload: message }, '*');
                    return;
                }
            } catch (_) {}
            // Fallback to legacy document events
            const evt = new CustomEvent('misinfoBackgroundMessage', {
                bubbles: true,
                composed: true,
                detail: { requestId, payload: message }
            });
            document.dispatchEvent(evt);
        });
    }
}

// Initialize sidebar when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new SidebarManager();
});

// Global error handler
window.addEventListener('error', (event) => {
    console.error('Sidebar error:', event.error);
});