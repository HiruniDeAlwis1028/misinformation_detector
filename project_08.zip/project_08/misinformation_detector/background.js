// Background service worker with minimal functionality
class BackgroundManager {
    constructor() {
        this.initialize();
    }

    initialize() {
        this.setupMessageHandlers();
        this.initializeStorage();
        console.log('Misinformation Detector background script initialized');
    }

    setupMessageHandlers() {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            switch (request.action) {
                case "analyzeText":
                    this.analyzeText(request.text).then(sendResponse);
                    return true;
                
                case "getHistory":
                    this.getHistory().then(sendResponse);
                    return true;
                
                case "clearHistory":
                    this.clearHistory().then(sendResponse);
                    return true;
                
                case "ping":
                    sendResponse({ status: 'alive' });
                    break;
            }
        });
    }

    initializeStorage() {
        chrome.storage.local.get(['analysisHistory'], (result) => {
            if (!result.analysisHistory) {
                chrome.storage.local.set({ 
                    analysisHistory: [],
                    settings: {
                        autoAnalyze: true,
                        showConfidence: true,
                        theme: 'light'
                    }
                });
            }
        });
    }

    async analyzeText(text) {
        try {
            // Simulate AI analysis (replace with actual API call)
            const analysis = await this.performAnalysis(text);
            await this.saveAnalysis(analysis);
            
            return {
                success: true,
                analysis: analysis
            };
        } catch (error) {
            console.error('Analysis error:', error);
            return {
                success: false,
                error: 'Analysis failed: ' + error.message
            };
        }
    }

    async performAnalysis(text) {
        return new Promise((resolve) => {
            // Simulate processing time
            setTimeout(() => {
                const riskScore = this.calculateRiskScore(text);
                const credibility = this.assessCredibility(riskScore);
                const keywords = this.extractKeywords(text);
                
                resolve({
                    text: text.substring(0, 500), // Limit text size
                    riskScore: riskScore,
                    credibility: credibility,
                    keywords: keywords,
                    explanation: this.generateExplanation(riskScore, keywords),
                    suggestions: this.generateSuggestions(riskScore),
                    timestamp: new Date().toISOString(),
                    id: Date.now().toString()
                });
            }, 1000);
        });
    }

    calculateRiskScore(text) {
        let score = 0;
        const lowerText = text.toLowerCase();
        
        // Check for sensational language
        const sensationalWords = ['shocking', 'amazing', 'miracle', 'secret', 'conspiracy', 'cover-up'];
        sensationalWords.forEach(word => {
            if (lowerText.includes(word)) score += 10;
        });
        
        // Check for urgency language
        const urgencyWords = ['urgent', 'breaking', 'immediately', 'warning'];
        urgencyWords.forEach(word => {
            if (lowerText.includes(word)) score += 5;
        });
        
        // Check for excessive punctuation
        const exclamationCount = (text.match(/!/g) || []).length;
        const questionCount = (text.match(/\?/g) || []).length;
        score += Math.min(exclamationCount * 2, 10);
        score += Math.min(questionCount, 5);
        
        return Math.min(100, Math.max(0, score));
    }

    assessCredibility(riskScore) {
        if (riskScore < 20) {
            return { level: 'HIGH', color: '#4CAF50' };
        } else if (riskScore < 50) {
            return { level: 'MEDIUM', color: '#FF9800' };
        } else {
            return { level: 'LOW', color: '#F44336' };
        }
    }

    extractKeywords(text) {
        const keywords = [
            'fake', 'hoax', 'conspiracy', 'false flag', 'deep state',
            'miracle cure', 'big pharma', 'mainstream media', 'cover up'
        ];
        
        const found = keywords.filter(keyword => 
            text.toLowerCase().includes(keyword.toLowerCase())
        );
        
        return {
            found: found,
            count: found.length
        };
    }

    generateExplanation(riskScore, keywords) {
        if (riskScore < 20) {
            return "This content appears credible with minimal misinformation indicators detected.";
        } else if (riskScore < 50) {
            return `This content shows some characteristics that require verification. ${keywords.count > 0 ? 'Detected potential indicators.' : ''}`;
        } else {
            return "This content exhibits multiple misinformation red flags and should be verified carefully.";
        }
    }

    generateSuggestions(riskScore) {
        const baseSuggestions = [
            "Verify with multiple reliable sources",
            "Check the publication date and author",
            "Look for primary sources and evidence",
            "Consult fact-checking organizations"
        ];
        
        if (riskScore > 50) {
            baseSuggestions.unshift("Exercise caution - high misinformation risk detected");
        }
        
        return baseSuggestions;
    }

    async saveAnalysis(analysis) {
        try {
            const result = await chrome.storage.local.get(['analysisHistory']);
            const history = result.analysisHistory || [];
            
            history.unshift(analysis);
            // Keep only last 20 analyses
            const limitedHistory = history.slice(0, 20);
            
            await chrome.storage.local.set({ analysisHistory: limitedHistory });
        } catch (error) {
            console.error('Error saving analysis:', error);
        }
    }

    async getHistory() {
        try {
            const result = await chrome.storage.local.get(['analysisHistory']);
            return result.analysisHistory || [];
        } catch (error) {
            console.error('Error getting history:', error);
            return [];
        }
    }

    async clearHistory() {
        try {
            await chrome.storage.local.set({ analysisHistory: [] });
            return { success: true };
        } catch (error) {
            console.error('Error clearing history:', error);
            return { success: false, error: error.message };
        }
    }
}

// Initialize background manager
const backgroundManager = new BackgroundManager();