/**
 * Misinformation Detector Content Script
 * Safe, non-intrusive implementation - NO SCROLL BLOCKING
 */

class ContentScript {
    constructor() {
        this.floatingButton = null;
        this.sidebarContainer = null;
        this.backdrop = null;
        this.selectedText = '';
        this.isSidebarOpen = false;
        
        this.init();
    }

    init() {
        this.setupSelectionListener();
        this.setupMessageListener();
        this.createSidebarStructure();
        
        console.log('Misinformation Detector content script loaded');
    }

    setupSelectionListener() {
        let selectionTimer;
        
        document.addEventListener('mouseup', (e) => {
            const selection = window.getSelection();
            const text = selection.toString().trim();
            
            clearTimeout(selectionTimer);
            
            if (text.length > 10) {
                selectionTimer = setTimeout(() => {
                    this.handleTextSelection(text, e);
                }, 200);
            } else {
                this.hideFloatingButton();
            }
        });

        document.addEventListener('mousedown', (e) => {
            if (this.floatingButton && !this.floatingButton.contains(e.target)) {
                this.hideFloatingButton();
            }
        });

        // Close sidebar on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isSidebarOpen) {
                this.hideSidebar();
            }
        });
    }

    setupMessageListener() {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            switch (request.action) {
                case 'showSidebar':
                    if (request.text) {
                        this.selectedText = request.text;
                        this.showSidebar();
                    }
                    sendResponse({ success: true });
                    break;
                    
                case 'hideSidebar':
                    this.hideSidebar();
                    sendResponse({ success: true });
                    break;
                    
                case 'getSelectedText':
                    sendResponse({ 
                        selectedText: this.selectedText || window.getSelection().toString().trim() 
                    });
                    break;
                    
                case 'ping':
                    sendResponse({ status: 'active' });
                    break;
                    
                case 'analyzePage':
                    this.analyzeCurrentPage().then(sendResponse);
                    return true;
            }
        });

        // Handle iframe postMessage events for background bridge and readiness
        window.addEventListener('message', async (event) => {
            const data = event.data || {};
            if (!data || typeof data !== 'object') return;

            if (data.type === 'misinfo:sidebarReady') {
                // Send selected text when sidebar signals ready
                if (this.isSidebarOpen && this.selectedText) {
                    this.sendToSidebar({ type: 'misinfo:setSelectedText', text: this.selectedText });
                }
                return;
            }

            if (data.type === 'misinfo:backgroundRequest') {
                const { requestId, payload } = data;
                if (!requestId || !payload) return;
                try {
                    const response = await chrome.runtime.sendMessage(payload);
                    if (this.sidebarFrame && this.sidebarFrame.contentWindow) {
                        this.sidebarFrame.contentWindow.postMessage({ type: 'misinfo:backgroundResponse', requestId, response }, '*');
                    }
                } catch (error) {
                    if (this.sidebarFrame && this.sidebarFrame.contentWindow) {
                        this.sidebarFrame.contentWindow.postMessage({ type: 'misinfo:backgroundResponse', requestId, response: { success: false, error: error?.message || 'Bridge error' } }, '*');
                    }
                }
            }
        });
    }

    handleTextSelection(text, event) {
        if (!text || text.length < 10) {
            this.hideFloatingButton();
            return;
        }
        
        this.selectedText = text;
        this.showFloatingButton(event);
    }

    showFloatingButton(event) {
        this.hideFloatingButton();
        
        this.floatingButton = document.createElement('button');
        this.floatingButton.className = 'misinfo-floating-btn';
        this.floatingButton.innerHTML = '🤖 Analyze';
        this.floatingButton.setAttribute('aria-label', 'Analyze selected text for misinformation');
        this.floatingButton.setAttribute('title', 'Analyze for misinformation');
        
        // Position near cursor
        const x = event.pageX + 10;
        const y = event.pageY - 50;
        
        this.floatingButton.style.left = Math.min(x, window.innerWidth - 120) + 'px';
        this.floatingButton.style.top = Math.max(y, 10) + 'px';
        
        this.floatingButton.addEventListener('click', (e) => {
            e.stopPropagation();
            this.showSidebar();
        });
        
        document.body.appendChild(this.floatingButton);
        
        // Animate in
        requestAnimationFrame(() => {
            this.floatingButton.classList.add('visible');
        });
    }

    hideFloatingButton() {
        if (this.floatingButton) {
            this.floatingButton.classList.remove('visible');
            setTimeout(() => {
                if (this.floatingButton && this.floatingButton.parentNode) {
                    this.floatingButton.parentNode.removeChild(this.floatingButton);
                }
                this.floatingButton = null;
            }, 300);
        }
    }

    createSidebarStructure() {
        // Create backdrop
        this.backdrop = document.createElement('div');
        this.backdrop.className = 'misinfo-backdrop';
        this.backdrop.addEventListener('click', () => this.hideSidebar());
        // Allow page scrolling when backdrop is visible by forwarding wheel/touch
        this.backdrop.addEventListener('wheel', (e) => {
            // Forward scroll to the window to avoid scroll lock
            window.scrollBy({ top: e.deltaY, left: 0, behavior: 'auto' });
        }, { passive: true });
        let _touchStartY = 0;
        this.backdrop.addEventListener('touchstart', (e) => {
            if (e.touches && e.touches.length > 0) {
                _touchStartY = e.touches[0].clientY;
            }
        }, { passive: true });
        this.backdrop.addEventListener('touchmove', (e) => {
            if (e.touches && e.touches.length > 0) {
                const currentY = e.touches[0].clientY;
                const deltaY = _touchStartY - currentY;
                window.scrollBy({ top: deltaY, left: 0, behavior: 'auto' });
                _touchStartY = currentY;
            }
        }, { passive: true });
        
        // Create sidebar container
        this.sidebarContainer = document.createElement('div');
        this.sidebarContainer.className = 'misinfo-sidebar-container';
        this.sidebarContainer.id = 'misinfo-sidebar';
        
        document.body.appendChild(this.backdrop);
        document.body.appendChild(this.sidebarContainer);
        
        this.loadSidebarContent();
    }

    async loadSidebarContent() {
        try {
            // Load sidebar in an iframe to bypass page CSP restrictions
            this.sidebarContainer.innerHTML = '';
            const iframe = document.createElement('iframe');
            iframe.src = chrome.runtime.getURL('sidebar/sidebar.html');
            iframe.style.border = '0';
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            iframe.setAttribute('title', 'Misinformation Detector Sidebar');
            this.sidebarContainer.appendChild(iframe);
            this.sidebarFrame = iframe;
        } catch (error) {
            console.error('Error loading sidebar:', error);
            this.loadFallbackSidebar();
        }
    }

    loadFallbackSidebar() {
        this.sidebarContainer.innerHTML = `
            <div style="padding: 20px; color: #333; height: 100%; display: flex; flex-direction: column;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h3 style="margin: 0;">🤖 Misinformation Detector</h3>
                    <button onclick="window.misinfoContent.hideSidebar()" style="padding: 8px 16px; background: #667eea; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        Close
                    </button>
                </div>
                <div style="flex: 1; display: flex; align-items: center; justify-content: center;">
                    <p>Error loading sidebar. Please refresh the page.</p>
                </div>
            </div>
        `;
        
        // Make content script accessible for fallback
        window.misinfoContent = this;
    }

    showSidebar() {
        this.hideFloatingButton();
        
        // REMOVED scroll blocking code
        // document.body.classList.add('misinfo-no-scroll');
        
        // Show backdrop and sidebar
        this.backdrop.classList.add('active');
        this.sidebarContainer.classList.add('open');
        this.isSidebarOpen = true;
        
        // Notify sidebar of selected text (iframe messaging)
        this.sendToSidebar({
            type: 'misinfo:setSelectedText',
            text: this.selectedText
        });
    }

    hideSidebar() {
        // REMOVED scroll restoration code
        // document.body.classList.remove('misinfo-no-scroll');
        
        // Hide backdrop and sidebar
        this.backdrop.classList.remove('active');
        this.sidebarContainer.classList.remove('open');
        this.isSidebarOpen = false;
        
        // Clear selection
        window.getSelection().removeAllRanges();
    }

    sendToSidebar(message) {
        // Prefer iframe messaging when available
        try {
            if (this.sidebarFrame && this.sidebarFrame.contentWindow) {
                this.sidebarFrame.contentWindow.postMessage(message, '*');
                return;
            }
        } catch (_) {}

        // Fallback to CustomEvent if iframe not ready (legacy path)
        const event = new CustomEvent('misinfoMessage', {
            bubbles: true,
            composed: true,
            detail: message
        });
        this.sidebarContainer.dispatchEvent(event);
    }
    
    async analyzeCurrentPage() {
        try {
            const content = this.extractPageContent();
            const response = await chrome.runtime.sendMessage({
                action: 'analyzeText',
                text: content
            });
            
            return response;
        } catch (error) {
            return { success: false, error: error.message };
        }
    }
    
    extractPageContent() {
        // Simple content extraction - limit to prevent performance issues
        const contentSelectors = [
            'article',
            '.article-content',
            '.post-content',
            '.story-content',
            'main',
            '[role="main"]'
        ];
        
        for (const selector of contentSelectors) {
            const element = document.querySelector(selector);
            if (element) {
                return element.textContent?.substring(0, 2000) || '';
            }
        }
        
        // Fallback to body content (limited)
        return document.body.textContent?.substring(0, 2000) || '';
    }
}

// Safe initialization
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new ContentScript();
    });
} else {
    new ContentScript();
}

// Error boundary
window.addEventListener('error', (event) => {
    console.error('Content script error:', event.error);
});

// Bridge: listen for sidebar close request and background requests
document.addEventListener('misinfoCloseSidebar', () => {
    try {
        const instance = window.misinfoContentInstance;
        if (instance && typeof instance.hideSidebar === 'function') {
            instance.hideSidebar();
        }
    } catch (_) {}
});

// Keep a reference to the content script instance for fallback handlers
(function attachInstanceRef() {
    try {
        // The instance is created above synchronously; find it via a weak ref
        // by hooking the prototype showSidebar, then saving `this` on first call
        const OriginalShow = ContentScript.prototype.showSidebar;
        ContentScript.prototype.showSidebar = function() {
            window.misinfoContentInstance = this;
            return OriginalShow.apply(this, arguments);
        };
    } catch (_) {}
})();

// Relay background requests from sidebar running in page context
document.addEventListener('misinfoBackgroundMessage', async (e) => {
    const { requestId, payload } = e.detail || {};
    if (!requestId || !payload) return;
    try {
        const response = await chrome.runtime.sendMessage(payload);
        const respEvent = new CustomEvent('misinfoBackgroundResponse', {
            bubbles: true,
            composed: true,
            detail: { requestId, response }
        });
        document.dispatchEvent(respEvent);
    } catch (error) {
        const respEvent = new CustomEvent('misinfoBackgroundResponse', {
            bubbles: true,
            composed: true,
            detail: { requestId, response: { success: false, error: error?.message || 'Bridge error' } }
        });
        document.dispatchEvent(respEvent);
    }
});