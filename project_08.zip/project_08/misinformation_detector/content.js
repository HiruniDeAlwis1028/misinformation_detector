/**
 * Misinformation Detector Content Script
 * Safe, non-intrusive implementation - NO SCROLL BLOCKING
 */

class ContentScript {
    constructor() {
        this.floatingButton = null;
        this.sidebarContainer = null;
        this.backdrop = null;
        this.selectedText = '';
        this.isSidebarOpen = false;
        
        this.init();
    }

    init() {
        this.setupSelectionListener();
        this.setupMessageListener();
        this.createSidebarStructure();
        
        console.log('Misinformation Detector content script loaded');
    }

    setupSelectionListener() {
        let selectionTimer;
        
        document.addEventListener('mouseup', (e) => {
            const selection = window.getSelection();
            const text = selection.toString().trim();
            
            clearTimeout(selectionTimer);
            
            if (text.length > 10) {
                selectionTimer = setTimeout(() => {
                    this.handleTextSelection(text, e);
                }, 200);
            } else {
                this.hideFloatingButton();
            }
        });

        document.addEventListener('mousedown', (e) => {
            if (this.floatingButton && !this.floatingButton.contains(e.target)) {
                this.hideFloatingButton();
            }
        });

        // Close sidebar on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isSidebarOpen) {
                this.hideSidebar();
            }
        });
    }

    setupMessageListener() {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            switch (request.action) {
                case 'showSidebar':
                    if (request.text) {
                        this.selectedText = request.text;
                        this.showSidebar();
                    }
                    sendResponse({ success: true });
                    break;
                    
                case 'hideSidebar':
                    this.hideSidebar();
                    sendResponse({ success: true });
                    break;
                    
                case 'getSelectedText':
                    sendResponse({ 
                        selectedText: this.selectedText || window.getSelection().toString().trim() 
                    });
                    break;
                    
                case 'ping':
                    sendResponse({ status: 'active' });
                    break;
                    
                case 'analyzePage':
                    this.analyzeCurrentPage().then(sendResponse);
                    return true;
            }
        });
    }

    handleTextSelection(text, event) {
        if (!text || text.length < 10) {
            this.hideFloatingButton();
            return;
        }
        
        this.selectedText = text;
        this.showFloatingButton(event);
    }

    showFloatingButton(event) {
        this.hideFloatingButton();
        
        this.floatingButton = document.createElement('button');
        this.floatingButton.className = 'misinfo-floating-btn';
        this.floatingButton.innerHTML = '🤖 Analyze';
        this.floatingButton.setAttribute('aria-label', 'Analyze selected text for misinformation');
        this.floatingButton.setAttribute('title', 'Analyze for misinformation');
        
        // Position near cursor
        const x = event.pageX + 10;
        const y = event.pageY - 50;
        
        this.floatingButton.style.left = Math.min(x, window.innerWidth - 120) + 'px';
        this.floatingButton.style.top = Math.max(y, 10) + 'px';
        
        this.floatingButton.addEventListener('click', (e) => {
            e.stopPropagation();
            this.showSidebar();
        });
        
        document.body.appendChild(this.floatingButton);
        
        // Animate in
        requestAnimationFrame(() => {
            this.floatingButton.classList.add('visible');
        });
    }

    hideFloatingButton() {
        if (this.floatingButton) {
            this.floatingButton.classList.remove('visible');
            setTimeout(() => {
                if (this.floatingButton && this.floatingButton.parentNode) {
                    this.floatingButton.parentNode.removeChild(this.floatingButton);
                }
                this.floatingButton = null;
            }, 300);
        }
    }

    createSidebarStructure() {
        // Create backdrop
        this.backdrop = document.createElement('div');
        this.backdrop.className = 'misinfo-backdrop';
        this.backdrop.addEventListener('click', () => this.hideSidebar());
        
        // Create sidebar container
        this.sidebarContainer = document.createElement('div');
        this.sidebarContainer.className = 'misinfo-sidebar-container';
        this.sidebarContainer.id = 'misinfo-sidebar';
        
        document.body.appendChild(this.backdrop);
        document.body.appendChild(this.sidebarContainer);
        
        this.loadSidebarContent();
    }

    async loadSidebarContent() {
        try {
            const sidebarUrl = chrome.runtime.getURL('sidebar/sidebar.html');
            const response = await fetch(sidebarUrl);
            
            if (!response.ok) throw new Error('Failed to load sidebar');
            
            const html = await response.text();
            this.sidebarContainer.innerHTML = html;
            
            // Load CSS
            const cssUrl = chrome.runtime.getURL('sidebar/sidebar.css');
            const cssResponse = await fetch(cssUrl);
            const cssText = await cssResponse.text();
            
            const style = document.createElement('style');
            style.textContent = cssText;
            this.sidebarContainer.appendChild(style);
            
            // Load JS
            const jsUrl = chrome.runtime.getURL('sidebar/sidebar.js');
            const jsResponse = await fetch(jsUrl);
            const jsText = await jsResponse.text();
            
            const script = document.createElement('script');
            script.textContent = jsText;
            this.sidebarContainer.appendChild(script);
            
        } catch (error) {
            console.error('Error loading sidebar:', error);
            this.loadFallbackSidebar();
        }
    }

    loadFallbackSidebar() {
        this.sidebarContainer.innerHTML = `
            <div style="padding: 20px; color: #333; height: 100%; display: flex; flex-direction: column;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h3 style="margin: 0;">🤖 Misinformation Detector</h3>
                    <button onclick="window.misinfoContent.hideSidebar()" style="padding: 8px 16px; background: #667eea; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        Close
                    </button>
                </div>
                <div style="flex: 1; display: flex; align-items: center; justify-content: center;">
                    <p>Error loading sidebar. Please refresh the page.</p>
                </div>
            </div>
        `;
        
        // Make content script accessible for fallback
        window.misinfoContent = this;
    }

    showSidebar() {
        this.hideFloatingButton();
        
        // REMOVED scroll blocking code
        // document.body.classList.add('misinfo-no-scroll');
        
        // Show backdrop and sidebar
        this.backdrop.classList.add('active');
        this.sidebarContainer.classList.add('open');
        this.isSidebarOpen = true;
        
        // Notify sidebar of selected text
        this.sendToSidebar({
            action: 'setSelectedText',
            text: this.selectedText
        });
    }

    hideSidebar() {
        // REMOVED scroll restoration code
        // document.body.classList.remove('misinfo-no-scroll');
        
        // Hide backdrop and sidebar
        this.backdrop.classList.remove('active');
        this.sidebarContainer.classList.remove('open');
        this.isSidebarOpen = false;
        
        // Clear selection
        window.getSelection().removeAllRanges();
    }

    sendToSidebar(message) {
        // Dispatch event to communicate with sidebar
        const event = new CustomEvent('misinfoMessage', {
            detail: message
        });
        this.sidebarContainer.dispatchEvent(event);
    }
    
    async analyzeCurrentPage() {
        try {
            const content = this.extractPageContent();
            const response = await chrome.runtime.sendMessage({
                action: 'analyzeText',
                text: content
            });
            
            return response;
        } catch (error) {
            return { success: false, error: error.message };
        }
    }
    
    extractPageContent() {
        // Simple content extraction - limit to prevent performance issues
        const contentSelectors = [
            'article',
            '.article-content',
            '.post-content',
            '.story-content',
            'main',
            '[role="main"]'
        ];
        
        for (const selector of contentSelectors) {
            const element = document.querySelector(selector);
            if (element) {
                return element.textContent?.substring(0, 2000) || '';
            }
        }
        
        // Fallback to body content (limited)
        return document.body.textContent?.substring(0, 2000) || '';
    }
}

// Safe initialization
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new ContentScript();
    });
} else {
    new ContentScript();
}

// Error boundary
window.addEventListener('error', (event) => {
    console.error('Content script error:', event.error);
});