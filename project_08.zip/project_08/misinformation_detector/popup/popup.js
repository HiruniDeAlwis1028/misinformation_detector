class PopupManager {
    constructor() {
        this.initialize();
    }

    async initialize() {
        await this.loadStats();
        this.setupEventListeners();
        this.checkExtensionStatus();
    }

    async loadStats() {
        try {
            const history = await this.getAnalysisHistory();
            this.updateStats(history);
        } catch (error) {
            console.error('Error loading stats:', error);
            this.showError('Failed to load statistics');
        }
    }

    async getAnalysisHistory() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['analysisHistory'], (result) => {
                resolve(result.analysisHistory || []);
            });
        });
    }

    updateStats(history) {
        const analysesCount = history.length;
        const avgRisk = this.calculateAverageRisk(history);
        
        document.getElementById('analysesCount').textContent = analysesCount;
        document.getElementById('avgRisk').textContent = avgRisk;
    }

    calculateAverageRisk(history) {
        if (history.length === 0) return 'Low';
        
        const totalRisk = history.reduce((sum, analysis) => sum + (analysis.riskScore || 0), 0);
        const averageRisk = totalRisk / history.length;
        
        if (averageRisk < 20) return 'Low';
        if (averageRisk < 50) return 'Medium';
        return 'High';
    }

    setupEventListeners() {
        // Feature buttons
        document.getElementById('analyzeSelection').addEventListener('click', () => {
            this.activateSelectionMode();
        });

        document.getElementById('analyzePage').addEventListener('click', () => {
            this.analyzeCurrentPage();
        });

        document.getElementById('viewHistory').addEventListener('click', () => {
            this.viewHistory();
        });

        document.getElementById('openSettings').addEventListener('click', () => {
            this.openSettings();
        });

        // Footer buttons
        document.getElementById('refreshBtn').addEventListener('click', () => {
            this.refresh();
        });

        document.getElementById('helpBtn').addEventListener('click', () => {
            this.showHelp();
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                window.close();
            }
        });
    }

    async activateSelectionMode() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            await chrome.tabs.sendMessage(tab.id, { action: 'ping' });
            
            this.showMessage('Select text on the page to analyze it');
            setTimeout(() => window.close(), 1500);
            
        } catch (error) {
            this.showError('Please refresh the page and try again');
        }
    }

    async analyzeCurrentPage() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            const response = await chrome.tabs.sendMessage(tab.id, {
                action: 'analyzePage'
            });
            
            if (response && response.success) {
                this.showMessage('Page analysis started');
                setTimeout(() => window.close(), 1000);
            } else {
                this.showError('Could not analyze page content');
            }
            
        } catch (error) {
            this.showError('Please refresh the page and try again');
        }
    }

    viewHistory() {
        // In a real implementation, this would open a history page
        this.showMessage('History feature coming soon');
    }

    openSettings() {
        // In a real implementation, this would open options page
        this.showMessage('Settings feature coming soon');
    }

    refresh() {
        this.loadStats();
        this.showMessage('Refreshed!');
    }

    showHelp() {
        chrome.tabs.create({
            url: chrome.runtime.getURL('help.html')
        });
        window.close();
    }

    async checkExtensionStatus() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const response = await chrome.tabs.sendMessage(tab.id, { action: 'ping' });
            
            if (!response) {
                this.updateStatus('inactive');
            }
        } catch (error) {
            this.updateStatus('inactive');
        }
    }

    updateStatus(status) {
        const statusDot = document.querySelector('.status-dot.active');
        const statusText = document.querySelector('.status-item:first-child span:last-child');
        
        if (status === 'inactive') {
            statusDot.style.background = '#f44336';
            statusText.textContent = 'Extension: Inactive (refresh page)';
        }
    }

    showMessage(message) {
        this.showNotification(message, 'success');
    }

    showError(message) {
        this.showNotification(message, 'error');
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `popup-notification ${type}`;
        notification.textContent = message;
        
        Object.assign(notification.style, {
            position: 'fixed',
            top: '10px',
            left: '50%',
            transform: 'translateX(-50%)',
            background: type === 'error' ? '#f44336' : '#4CAF50',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '4px',
            fontSize: '12px',
            zIndex: '10000',
            maxWidth: '300px',
            textAlign: 'center'
        });
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 3000);
    }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PopupManager();
});